package labbook10;
import java.util.*;
	

	interface MathOperation
	{
		double Operation(int x,int y);
	}
	public class Exercise1 {
	public static void main(String[] args) {
	MathOperation power=(int x,int y) ->Math.pow(x, y);
	System.out.println(power.Operation(3, 4));
	}
	}

