package labbook10;

	import java.util.*;
	interface StringOperations
	{
		String Operation(String s);
	}
	public class Exercise2 {
	public static void main(String[] args) {
		StringOperations space=(String str)->{
			String str2="";
			for(int i=0;i<str.length();i++){
				char c=str.charAt(i);
				str2=str2+c;
				str2=str2+'\t';
			}
			return str2;
		};
		System.out.println(space.Operation("CG"));
	}
}
