package labbook8;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class Exercise2 extends TimerTask implements Runnable
	{
		public void run()
		{
			System.out.println("Timer Update....."+new Date());
		}
		public static void main(String[] args) throws InterruptedException
		{
			TimerTask timertask=new Exercise2();
			Timer timer=new Timer();
			timer.scheduleAtFixedRate(timertask,0,10*1000);
			System.out.println("Timer Update is started");
			Thread.sleep(100000);
			timer.cancel();
			System.out.println("Timer Update is stopped ");
			
			
		}

	}


