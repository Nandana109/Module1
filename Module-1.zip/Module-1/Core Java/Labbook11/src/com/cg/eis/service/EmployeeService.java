package com.cg.eis.service;

import com.cg.eis.bean.EmployeeBean;
import com.cg.eis.pl.EmployeePl;

public class EmployeeService {
	public int addEmp(float salary)
	{
		String designation=null;
		String InsuranceScheme=null;
		
		if(salary>5000 &&salary < 20000)
		{
			
			designation="System Associate";
			InsuranceScheme="C";
		}
		else if(salary>=20000 &&salary<40000)
		{
			designation="Programmer";
			InsuranceScheme=" B";
			}
	else if(salary>=40000)
	{
		designation="Manager";
		InsuranceScheme=" A";
		}
		else {
			designation=" Clerk";
			InsuranceScheme=" No Scheme";
			
		}
			
		EmployeePl empPl=new EmployeePl();
		EmployeeBean empBean=new EmployeeBean();
		empBean.setSalary(salary);
		empBean.setDesignation(designation);
		empBean.setInsuranceScheme(InsuranceScheme);
		//bookBean.setGrade(grade);
		int updateResult=0;
		try
		{
			updateResult=empPl.addEmp1(empBean);
			return updateResult;
		}
		catch(Exception e)
		{
			System.out.println("Exception resolved");
		}
		return 0;
	}
	}

