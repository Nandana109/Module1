package com.cg.eis.pl;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cg.eis.bean.EmployeeBean;
public class EmployeePl {
	public int addEmp1(EmployeeBean empBean)
	{
		Connection con=null;
		PreparedStatement pst=null;
		try
		{
			con=EmployeeDB.getConnection1();
			pst=con.prepareStatement("insert into emp values(?,?,?)");
			pst.setFloat(1, empBean.getSalary());
			pst.setString(2, empBean.getDesignation());
			pst.setString(3, empBean.getInsuranceScheme());
			//pst.setString(4, empBean.getGrade());
			int updateCount=pst.executeUpdate();
			return updateCount;
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return 0;
		
	}
	}

