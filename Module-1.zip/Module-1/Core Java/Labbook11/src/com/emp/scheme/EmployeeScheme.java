package com.emp.scheme;

import java.util.Scanner;

import com.cg.eis.service.EmployeeService;
public class EmployeeScheme 
{
	public static void main(String[] args) {
		float salary=0;
		//String designation="";
		//String InsuranceScheme="";
		Scanner sc=new Scanner(System.in);
		System.out.println("enter salary");
		salary=sc.nextFloat();
		sc.nextLine();
		/*System.out.println("enter designation");
		designation=sc.next();
		sc.nextLine();
		System.out.println("enter insurance scheme");
		InsuranceScheme=sc.next();
*/		EmployeeService bookService=new EmployeeService();
		int updateCount=bookService.addEmp(salary);
		System.out.println(updateCount);
		}
	}
