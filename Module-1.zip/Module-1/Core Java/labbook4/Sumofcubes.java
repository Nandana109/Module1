package lab4book;

import java.util.Scanner;

class Sumofcubes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n,i,p,sum=0;
Scanner s=new Scanner(System.in);
System.out.println("enter number");
n=s.nextInt();
for(i=0;i<n;i++)
{
	p=n%10;
	sum=sum+(p*p*p);
	n=n/10;
	
}
System.out.println(sum);
	}

}
