// using non recursive function
import java.util.Scanner;

public class Exercise2Recursenon {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter fibonacci series");
		int size=sc.nextInt();
		
		int f1=1;
		int f2=1;
		int f3 = 0;
		System.out.print(f1);
		System.out.print(" "+f2);
		for(int i=0;i<size-2;i++)
		{
			f3=f1+f2;
			f1=f2;
			f2=f3;
			System.out.print(" "+f3);
		}
		System.out.println();
	}

}

