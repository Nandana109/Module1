import java.util.Scanner;

public class Exercise1 {

	public static void main(String[] args) {
System.out.println("enter traffic light");
Scanner sc=new Scanner(System.in);
String s=sc.nextLine();
switch(s)
{
case "red":
	System.out.println("stop");
	break;
case "yellow":
	System.out.println("ready");
	break;
case "green":
	System.out.println("go");
	break;
}
	}

}
