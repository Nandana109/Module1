package lab3_labbook;

	
public class Secondlargest {
	public static int getSecondSmallest(int[] a)
	{
		int i,j,temp;
		int n=a.length;
		//int a={1,6,3,6,2,3};
		for(i=0;i<n;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if(a[i]>=a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		return a[1];
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int a[]={9,8,4,3};
	//getSecondSmallest g=new getSecondLargest();
	System.out.println(getSecondSmallest(a));
	}

}
