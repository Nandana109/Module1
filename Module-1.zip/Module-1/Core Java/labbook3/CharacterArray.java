package lab3_labbook;
 
import java.util.Scanner;
 
public class CharacterArray {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = null;
		System.out.println("Enter String : ");
		s = sc.nextLine();
		int[] count = new int[255];
 
		int length = s.length();
 
		for (int i = 0; i < length; i++) {
			count[s.charAt(i)]++;
		}
 
		char[] ch = new char[s.length()];
		for (int i = 0; i < length; i++) {
			ch[i] = s.charAt(i);
			int c = 0;
			for (int j = 0; j <= i; j++) {
				if (s.charAt(i) == ch[j])
					c++;
			}
 
			if (c == 1) {
				System.out.println(" letter " + s.charAt(i) +" is:" + count[s.charAt(i)]);
			}
		}
	}
}