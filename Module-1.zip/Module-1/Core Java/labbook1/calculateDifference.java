package lab1_labbook;

public class calculateDifference {
static int calculateDifference(int n){
int a[]= new int[20];
int i,j,p=0,q=0,sum,r=0;
for(i=1;i<=n;i++)
{
	a[i]=i*i;
	p=p+a[i];
}
for(j=1;j<=n;j++)
{
	a[j]=j;
	q=q+a[j];
	r=q*q;
}
return sum=p-r;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int n=10;
		System.out.println(calculateDifference(5));
	}

}
