package lab1_labbook;

import java.util.Scanner;

public class CheckPower {
	public static boolean power(int n)
	{
		//Scanner s=new Scanner(System.in);
		//System.out.println("enter number");
		//int n=s.nextInt();
		if(n==0)
		{
		return false;
		}
		while(n!=1)
		{
			if(n%2!=0)
			{
						n=n/2;
			}
						return false;
			
		}
		return false;
	}
	public static void main(String[] args) {
	
		//Scanner s=new Scanner(System.in);
		//System.out.println("enter number");
		//int p=s.nextInt();
	CheckPower c=new CheckPower();
	//c.power();
	System.out.println(power(16));
	}

}
