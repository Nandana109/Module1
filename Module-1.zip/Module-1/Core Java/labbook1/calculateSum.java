package lab1_labbook;

//logic: numbers from 1 to n that are divisible by 3 and 5
//eg: 9---> numbers that are divisible by 3 or 5 from 1 to 9 are 3,5,6,9
// so addition of 3+5+6+9=23


public class calculateSum {
	
	static int calculateSum(int n)
{	
	//System.out.println("enter a number:");
		int x=3,y=5;
    int s1=((n/x)*(2*x+(((n/x)-1)*x)))/2;
    int s2=((n/y)*(2*y+(((n/y)-1)*y)))/2;
    int s3=((n/(x*y))*(2*(x*y)+(((n/(x*y))-1)*(x*y))))/2;
    int sum=s1+s2-s3;
    return sum;
	
}
public static void main(String[] args) {
		// TODO Auto-generated method stub
	int n=9;
     System.out.println(calculateSum(n));
	
	}}

