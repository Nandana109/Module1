package lab1_labbook;
import java.util.Scanner;
public class checkNumber {
	//static int checkNumber(int n){
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 		Scanner s=new Scanner(System.in);
		System.out.println("enter number");
		int n=s.nextInt();
		int p=9;
		boolean i= true;
		while(n>0)
		{
		int c=n%10;
		n=n/10;
		if(c>p)
		{
		 i= false;
			break;
		}
		p=c;
		}
		System.out.println(" "+i);
	}
	}