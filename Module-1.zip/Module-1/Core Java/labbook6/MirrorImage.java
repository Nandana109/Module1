package lab6_labbook;
import java.lang.*; 
import java.io.*; 
import java.util.*; 
  
public interface MirrorImage {
	 
	    public static void main(String[] args) 
	    { 
	    	Scanner sc=new Scanner(System.in);
	    	
	        String input =sc.next();
	  
	        byte [] strAsByteArray = input.getBytes(); 
	  
	        byte [] result =  
	                   new byte [strAsByteArray.length]; 
	  
	       
	        for (int i = 0; i<strAsByteArray.length; i++) 
	            result[i] =  
	             strAsByteArray[strAsByteArray.length-i-1]; 
	        System.out.println(input+"|"+new String(result));
	   
	    } 
	} 


