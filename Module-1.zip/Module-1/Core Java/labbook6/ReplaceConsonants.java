package lab6_labbook;
	import java.io.BufferedReader;
	import java.io.IOException;
	import java.io.InputStreamReader;
	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.List;
	public class ReplaceConsonants {

	    public static void main(String args[]) throws IOException
	    {
	        List<Character> consonantList = new ArrayList<Character>();
	        consonantList.addAll(Arrays.asList('b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'));
	        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
	        char[] userInput = bufferedReader.readLine().toLowerCase().toCharArray();
	        for(int i=0;i<userInput.length;i++)
	        {
	            if(consonantList.contains(userInput[i]))
	            {
	                userInput[i]=consonantList.get((consonantList.indexOf(userInput[i])+1)%21);
	            }
	        }
	        System.out.println(String.valueOf(userInput));
	    }
	}